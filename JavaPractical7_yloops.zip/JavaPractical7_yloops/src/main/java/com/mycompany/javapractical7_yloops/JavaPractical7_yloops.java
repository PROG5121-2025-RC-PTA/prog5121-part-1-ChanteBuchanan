/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javapractical7_yloops;
import java.util.Scanner;

/**
 *
 * @author RC_Student_lab
 */
public class JavaPractical7_yloops {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        
        String registeredUsername = "";
        String registeredPassword = "";
        
        System.out.println("wlecome to the Registration page");
        
             //registration
             System.out.print("register your user name");
             registeredUsername = scanner.nextLine();
        
             System.out.print("register a password; ");
             registeredPassword = scanner.nextLine();
            
             System.out.print("\nRegistration successful");
             System.out.println("please log in to continue");
            
             //login
              int attempts = 0;
              int maxAttempts = 3;
              boolean isLoggedIn = false;
             
              while (attempts < maxAttempts && !isLoggedIn) {
                System.out.print("\nEnter username: ");
                String username = scanner.nextLine();
                
                System.out.print("enter password");
                String password = scanner.nextLine();
                
                if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                    System.out.println("login successful! welcome, " + username + "!");
                    isLoggedIn = true;
                }else {
                    attempts++;
                    int remaining = maxAttempts - attempts;
                System.out.println("incorrect username or password. Attempts remaining: " + remaining );        
            }            
        }
        if (!isLoggedIn) {
        System.out.println("too many failed attempts account locked");
        }
    
        scanner.close(); 
    }
}
